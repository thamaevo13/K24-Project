<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<center><h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

</center>