<?php
/* @var $this AnggotaController */
/* @var $model Anggota */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'anggota-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'Nama'); ?>
		<?php echo $form->textField($model,'nama',array('size'=>30,'maxlength'=>30)); ?>
		<?php echo $form->error($model,'nama'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'No HP'); ?>
		<?php echo $form->textField($model,'no_hp'); ?>
		<?php echo $form->error($model,'no_hp'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Tanggal Lahir'); ?>
		<?php echo $form->textField($model,'tgl_lahir');
		// $this->widget('zii.widgets.jui.CJuiDatePicker', array(
  //           'name'=>'MutationOrder[tgl_lahir]',
  //           'value'=>$model->tgl_lahir,
  //           'options'=>array(
  //               'showAnim'=>'fold',
  //               'dateFormat'=>'yy-mm-dd',
  //           ),
  //       ));
		 ?>
		<?php echo $form->error($model,'tgl_lahir'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Email'); ?>
		<?php echo $form->textField($model,'email',array('size'=>30,'maxlength'=>30)); ?>
		<?php echo $form->error($model,'email'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Jenis Kelamin'); ?>
		<?php echo $form->dropDownList($model,
                    'jk',
                    array('1'=>'Laki-Laki','0'=>'Perempuan'),
                    array('empty'=>'Select Option')
                );	
		 ?>
		<?php echo $form->error($model,'jk'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'No KTP'); ?>
		<?php echo $form->textField($model,'ktp',array('size'=>16,'maxlength'=>16)); ?>
		<?php echo $form->error($model,'ktp'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->