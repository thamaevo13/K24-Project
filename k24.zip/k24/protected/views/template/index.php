<h2>
Sejarah Yii Framework</h2>
<p align="justify">
Yii merupakangagasan pendirinya, Qiang Xue, yang memulai proyek Yii pada tanggal 1 Januari 2008. Qiang sebelumnya dikembangkan dan dipelihara dengan kerangka Prado. Tahun-tahun pengalaman yang diperoleh dan pengembang umpan balik yang dikumpulkan dari proyek yang dipadatkan kebutuhan untuk kerangka yang sangat cepat, aman dan profesional yang dibuat khusus untuk memenuhi harapan pengembangan aplikasi Web 2.0. Pada tanggal 3 Desember 2008, setelah pembangunan hampir satu tahun, Yii 1.0 secara resmi dirilis ke publik.</p>
<p align="justify">
Yii memiliki pengukuran kinerja yang sangat mengesankan jika dibandingkan dengan framework PHP lainnya, framework ini segera menarik perhatian yang sangat positif dan popularitas dan adopsi terus tumbuh pada tingkat yang semakin meningkat.</p>