<?php
class TemplateController extends Controller{
 public $layout="layoutweb2";
        function actionIndex(){
            $this->render("index");
        }      
}
?>